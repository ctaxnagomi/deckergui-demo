/**
 * DGUI emit-intent sandbox runner (child process).
 *
 * Launched by the Docking Station as:
 *   node --permission --allow-fs-read=<sourceDir> --allow-fs-write=<targetDir> \
 *        sandboxRunner.mjs <base64(spec)>
 *
 * The Node permission model makes this a real capability sandbox: the process
 * can read only inside <sourceDir>, write only inside <targetDir>, and cannot
 * spawn child processes or worker threads. The runner imports only node: builtins
 * (fs/path/crypto), so it performs no network access. This is the emit-intent-only
 * execution boundary for the compile+transfer workload.
 *
 * Evidence (verified against Node's permission model): writes outside the write
 * root throw ERR_ACCESS_DENIED, reads outside the read root throw ERR_ACCESS_DENIED,
 * and child_process spawn throws ERR_ACCESS_DENIED.
 *
 * Protocol: newline-delimited JSON on stdout.
 *   {"type":"progress","pct":<0-100>,"detail":"..."}   (zero or more)
 *   {"type":"result","ok":true,...}                    (exactly one, terminal)
 *   {"type":"error","stage":"...","error":"...","code":"..."}  (terminal, on denial)
 */

import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';

const sha256 = (s) => createHash('sha256').update(s).digest('hex');
const emit = (obj) => process.stdout.write(JSON.stringify(obj) + '\n');

/** Flush stdout, then exit — process.exit() alone can truncate piped writes. */
function finish(code) {
  process.stdout.write('', () => process.exit(code));
}

function fail(stage, err) {
  emit({ type: 'error', stage, error: err && err.message ? err.message : String(err), code: err && err.code ? err.code : undefined });
  finish(0);
  throw new Error('__sandbox_exit__');
}

try {
  let spec;
  try {
    spec = JSON.parse(Buffer.from(process.argv[2] ?? '', 'base64').toString('utf-8'));
  } catch (err) {
    fail('decode', err);
  }

  if (!spec || !spec.sourceDir || !spec.targetDir || !Array.isArray(spec.fileNames)) {
    fail('spec', new Error('sourceDir, targetDir, fileNames are required'));
  }

  const started = Date.now();
  emit({ type: 'progress', pct: 4, detail: `sandbox engaged — ${spec.title ?? spec.jobId ?? 'job'}` });

  const worklog = [
    { step: 'scope', at: started, note: `sandbox engaged — ${spec.title ?? spec.jobId ?? 'job'}`, step_detail: spec.steps ?? [] },
  ];
  const compiled = [];
  const total = spec.fileNames.length;

  try {
    mkdirSync(spec.targetDir, { recursive: true });
  } catch (err) {
    fail('mkdir-target', err);
  }

  for (let i = 0; i < total; i++) {
    const name = spec.fileNames[i];
    const at = Date.now();
    emit({ type: 'progress', pct: 6 + Math.round(((i) / total) * 88), detail: `compiling ${i + 1}/${total} · ${name}` });

    const src = join(spec.sourceDir, name);
    let present = false;
    try {
      present = existsSync(src);
    } catch (err) {
      fail('stat', err);
    }
    if (!present) {
      worklog.push({ step: 'skip', at, note: `${name} not found in ${spec.sourceDir}` });
      continue;
    }
    let raw;
    try {
      raw = readFileSync(src, 'utf-8');
    } catch (err) {
      fail('read', err);
    }
    const out = raw.startsWith('#')
      ? raw
      : `# compiled from ${spec.sourceDir} by ${spec.agentId ?? 'dock'} · ${spec.compileNote ?? 'compile'}\n${raw}`;
    const outName = name.replace(/\.csv$/, '.compiled.csv');
    try {
      writeFileSync(join(spec.targetDir, outName), out, 'utf-8');
    } catch (err) {
      fail('write', err);
    }
    compiled.push({ name: outName, bytes: Buffer.byteLength(out), sha256: sha256(out) });
    worklog.push({ step: 'compile', at, note: `${name} → ${outName}`, note2: `${Buffer.byteLength(out)}B` });
    emit({ type: 'progress', pct: 6 + Math.round(((i + 1) / total) * 88), detail: `compiled ${name} · ${i + 1}/${total}` });
  }

  emit({ type: 'progress', pct: 97, detail: 'validating compiled deliverables (sandbox)' });
  const manifestHash = sha256(compiled.map(f => `${f.name}:${f.sha256}`).join('\n'));
  try {
    writeFileSync(join(spec.targetDir, 'job.files.json'), JSON.stringify({
      schema: 'DGUI-COMPILE-MANIFEST-v1',
      agentId: spec.agentId ?? 'dock',
      jobId: spec.jobId,
      title: spec.title,
      sourceDir: spec.sourceDir,
      targetDir: spec.targetDir,
      budgetMs: spec.budgetMs,
      files: compiled,
      compiledAt: Date.now(),
      sandbox: { model: 'node-permission', read: spec.sourceDir, write: spec.targetDir },
    }, null, 2), 'utf-8');
  } catch (err) {
    fail('write-manifest', err);
  }

  emit({
    type: 'result',
    ok: true,
    files: compiled,
    manifestHash,
    compiled: compiled.length,
    planned: total,
    durationMs: Date.now() - started,
    worklog,
    sandbox: { model: 'node-permission', read: spec.sourceDir, write: spec.targetDir },
  });
} catch (e) {
  if (!(e && e.message === '__sandbox_exit__')) {
    emit({ type: 'error', stage: 'internal', error: e && e.message ? e.message : String(e) });
    finish(0);
  }
}

@echo off
rem DGUI Client — start the dock. Usage: dock-up.cmd [--port N]
setlocal
"%~dp0deckerGUI.exe" dock up %*

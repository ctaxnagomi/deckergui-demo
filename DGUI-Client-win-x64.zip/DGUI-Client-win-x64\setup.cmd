@echo off
rem DGUI Client — one-time setup. Usage: setup.cmd [PeerDeviceIP]
setlocal
set "PEER=%~1"
if "%PEER%"=="" set "PEER=192.168.0.5"

echo Configuring this device as a DGUI client dock (peer %PEER%)...
"%~dp0deckerGUI.exe" dock setup --human --intent work --mode lan --port 3198 ^
  --emitter "http://%PEER%:3006" --hub "http://%PEER%:3011" ^
  --vendor "Hosen Enterprise (Vendor)" --agent-id dgui-dock-client

echo.
echo Done. Next:  dock-up.cmd     (starts the dock)
echo Optional scannable: re-run with --force --scannable --lat ^<lat^> --lng ^<lng^>
